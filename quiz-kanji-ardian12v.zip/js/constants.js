export const BATCH_SIZE = 20;

export const KEYS = {
  kanji: "Kanji",
  meaning: "Arti",
  hiragana: "Hiragana",
  number: "No"
};

export const SELECTORS = {
  quizArea: "quiz-area",
  confetti: "confetti-wrapper",
  totalCount: "totalCount"
};